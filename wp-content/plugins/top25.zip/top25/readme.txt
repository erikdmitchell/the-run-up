Version 1.5.7
	file system on admin page utalizes jquery for hiding and showing files
	resorted our file out put with more detailed classes and ids
	splite files up by month
	
Version 1.5.6
	updated database to now store year for riders points (db-setup.php out of date)
	upload_race.php now accounts and looks for season (year) when matching riders
	
Version 1.5.5
	added add season to admin section
	
Version 1.5.4
	added CN type
	
Version 1.5.3
	fixed minor php glitches on top25_week_page.php and upload_race.php
	fixed undefined variables in admin_settings_page.php

Version 1.5.2
	reworked admin script inclusion and admin navigation
	fixed initial data from showing when db is not empty
	fixed shortcode not displaying properly (removed legacy compatability)
	removed legacy css (shortcode.css)
		
Version 1.5.1
	minor css changes
	aplit css into site and admin
	utalize wp built in jquery datepicker
	modified how we enqueue styles and scripts

Version 1.5.0
	init readme.txt
	
To Do:
	Setup Week:
		- Season Select
		- custom start/end dates
	Confirm our code (math)
	Voting is now done by me, perhaps weight needs to be changed
	
Potential Adds
	Up/Down from pervious week
	More detailed rider/race results (pages)
	CSV file upload