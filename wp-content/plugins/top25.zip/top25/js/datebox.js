jQuery(function($) {
	$(".datepicker").datepicker({
		dateFormat: "dd-m-yy",
	});

	$(".seasondatepicker").datepicker({
		dateFormat: "dd-mm-yy",
	});
});