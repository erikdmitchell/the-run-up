(function($) {
	$('.datepicker').datepicker({
		'dateFormat' : 'mm-dd-yy'
	});
})(jQuery);