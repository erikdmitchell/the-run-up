<?php
/**
 * Plugin Name: WordPress BitBucket Updater
 * Plugin URI: 
 * Description: This plugin is our automatic updater for (Private) BitBucket hosted repositories. It is designed to be implemented within itself.
 * Version: 0.1.4
 * Author: Erik Mitchell
 * Author URI: 
 * License: GPL2
 */
 
/*
Credit goes to the following plugins/slices of code for use in this plugin:
	bitbucket-updater.php - functionality and overall structure was modified from: https://github.com/jkudish/WordPress-GitHub-Plugin-Updater
	get_repo() (BitBucket Class) was derived forom: http://jamescollings.co.uk/blog/bitbucket-deployment-script/
	The BitBucket OAuth library and classes, along with some basic functions were found here: https://github.com/aprokopenko/bitbucketauthapi
Thanks to each of those three authors for their public code that we could utalize in this project.
*/

include_once(plugin_dir_path(__FILE__).'lib/bitbucket-updater.php');

// begin auto updater stuff //
if (is_admin()) :
	$config=array(
		'slug' => plugin_basename(__FILE__),
		'admin_username' => 'erikdmitchell',
		'repository_slug' => 'bitbucket-wp-plugin-tester',
		'repository_username' => 'erikdmitchell',
		'plugin_file' => 'bb-wp-plugin.php',
		'proper_folder_name' => 'bb-wp-plugin',
		'bb_username' => 'MDWMobileOAuth',
		'bb_password' => '', // not used
		'bb_oauth_key' => 'xTqNxD7HjWsvbJW934',
		'bb_oauth_secret' => 'kg6FweUhG9Fy59y2jkqcgS8CEdxBwAva',
		'sslverify' => true, // not used
		'requires' => '3.0',
		'tested' => '3.3',
		'readme' => 'README.md',
		'access_token' => '',	// not used
	);
	new WPBitBucketUpdater($config);	
endif;
?>